/* script.js - add interactivity: dark mode, search filter, slideshow, back-to-top, mobile nav toggle */

/* --- Dark Mode Toggle & persistence --- */
const toggleDark = () => {
  document.documentElement.classList.toggle('dark');
  if(document.documentElement.classList.contains('dark')) localStorage.setItem('cm_dark','1');
  else localStorage.removeItem('cm_dark');
}
window.addEventListener('DOMContentLoaded', () => {
  if(localStorage.getItem('cm_dark')) document.documentElement.classList.add('dark');
});

/* --- Simple search/filter for cards on page ---
   Place a <input id="siteSearch"> in header; each section page should include data-search on cards.
   The script will filter cards by matching text.
*/
function siteSearch(query){
  if(!query) {
    document.querySelectorAll('.card').forEach(c=>c.style.display='block'); return;
  }
  const q = query.toLowerCase().trim();
  document.querySelectorAll('.card').forEach(c=>{
    const text = (c.innerText||'').toLowerCase();
    c.style.display = text.includes(q) ? 'block' : 'none';
  });
}

/* bind search input if present */
const searchInput = document.getElementById('siteSearch');
if(searchInput){
  searchInput.addEventListener('input', e=> siteSearch(e.target.value));
}

/* --- Back to top button --- */
const topBtn = document.getElementById('topBtn');
window.addEventListener('scroll', ()=>{
  if(window.scrollY > 240) topBtn.style.display = 'block';
  else topBtn.style.display = 'none';
});
function topFunction(){ window.scrollTo({top:0,behavior:'smooth'}); }
if(topBtn) topBtn.addEventListener('click', topFunction);

/* --- Simple slideshow component (works if .slideshow present) --- */
function initSlides(containerSelector, delay=4000){
  const container = document.querySelector(containerSelector);
  if(!container) return;
  const slides = container.querySelectorAll('.slide');
  let idx = 0;
  function show(i){
    slides.forEach(s => s.style.display='none');
    slides[i].style.display='block';
  }
  show(idx);
  let timer = setInterval(()=>{ idx = (idx+1)%slides.length; show(idx); }, delay);
  const left = container.querySelector('.slide-btn.left');
  const right = container.querySelector('.slide-btn.right');
  if(left){ left.addEventListener('click', ()=>{ idx = (idx-1+slides.length)%slides.length; show(idx); clearInterval(timer); });}
  if(right){ right.addEventListener('click', ()=>{ idx = (idx+1)%slides.length; show(idx); clearInterval(timer); });}
}
document.addEventListener('DOMContentLoaded', ()=> initSlides('.slideshow',4000));

/* --- Small helper for mobile nav toggle if implemented --- */
function toggleNav(){
  const links = document.querySelector('.navlinks');
  if(!links) return;
  links.style.display = (links.style.display === 'flex') ? 'none' : 'flex';
}

/* attach window functions to global so HTML can call them */
window.toggleDark = toggleDark;
window.siteSearch = siteSearch;
window.topFunction = topFunction;
window.toggleNav = toggleNav;
window.initSlides = initSlides;