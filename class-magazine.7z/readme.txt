Class Magazine — quick instructions:

1. Replace images in /images with your photos.
2. Put your yearbook file at /yearbook.pdf (optional).
3. Deploy folder to Netlify:
   - Drag-and-drop the folder into Netlify dashboard OR push to GitHub and connect
4. Netlify Forms:
   - The contact form uses Netlify's form handling. Submissions appear in Netlify dashboard.
5. To zip:
   - Compress the 'class-magazine' folder into class-magazine.zip on your computer.